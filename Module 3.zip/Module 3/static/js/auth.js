const login_toogle_btn = document.getElementById("login-toogle-btn");

const signup_toogle_btn = document.getElementById("signup-toogle-btn");

const signup_form = document.getElementById("signup-form");
const login_form = document.getElementById("login-form");

signup_form.style.display = "none";
login_toogle_btn.style.borderBottom = "3px solid #503E9D";



login_toogle_btn.addEventListener("click", () => {
  signup_form.style.display = "none";
  login_form.style.display = "flex";
  login_toogle_btn.style.borderBottom = "3px solid #503E9D";
  signup_toogle_btn.style.borderBottom = "2px solid black";
});

signup_toogle_btn.addEventListener("click", () => {
  login_form.style.display = "none";
  signup_form.style.display = "flex";
  signup_toogle_btn.style.borderBottom = "3px solid #503E9D";
  login_toogle_btn.style.borderBottom = "2px solid black";
});





